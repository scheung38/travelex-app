# from splinter import Browser
#
# browser = Browser()
# url = 'http://localhost:5000'
# browser.visit(url)
# assert browser.is_text_present('Hello, Sebastian!')
# browser.quit()